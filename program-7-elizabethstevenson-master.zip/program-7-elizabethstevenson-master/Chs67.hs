module Chs67 where

--don't delete the import, obviously
--remember to include function types (3 points each)

sumdown :: Int -> Int
sumdown 0 = 0
sumdown n
    | n < 0 = 0
    | n > 0 = n + sumdown (n-1)

euclid :: Int -> Int -> Int
euclid a b | a <= 0, b <= 0 = 0
    | a == b = a
    | a > b = euclid (a - b) b
    | a < b = euclid a (b - a)

sum' :: (Num x) => [x] -> x
sum' [] = 0
sum' (a:b) = a + sum' b

take' :: Int -> [x] -> [x]
take' 0 _= []
take' x [] = []
take' x (a:b) = a : take' (x-1) b

last' :: [x] -> x
last' [x] = x
last' (a:b) = last' b

dec2int' :: [Int] -> Int
dec2int' x = sum [w*b | (w,b) <- zip weights (reverse x)]
    where weights = iterate (*10) 1

altmap :: (a -> b) -> (a -> b) -> [a] -> [b]
altmap _ _ [] = []
altmap x y [z] = [x z]
altmap x y (p : q : ps) = x p : y q : altmap x y ps

--define your own function(s) to help with luhn

luhn :: [Int] -> Bool
luhn [] = False
luhn xs = mod (sum $ altmap luhn' id xs) 10 == 0

luhn' :: Int -> Int
luhn' x
    | x*2 < 9   = 2*x
    | otherwise = 2*x - 9