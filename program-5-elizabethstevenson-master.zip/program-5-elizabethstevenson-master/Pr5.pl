%consider pattern matching and head-tail notation for these

exactly3(L):- list_length(L,N), N=:=3.

at_least_3(L):- list_length(L,N), N >= 3.

at_most_3(L):- list_length(L,N), N=<3.

intersect(L1,L2):- member(E,L1), member(E,L2).

all_intersect(X,_):- X = [], _ = [].
all_intersect(ListofLists,L):- ListofLists = [H|T], intersect(H,L), all_intersect(T,L).


list_length([],0).
list_length([_|X],L):- list_length(X,N), L is N+1.

%source removal, see pdf. You'll probably want to define helper predicates
% assume G is set and you need to return list of nodes
% as [a,b,d...], not [ [a|[v,d]], [b| [d] ], [d| [c,x]],... ]
source_removal(G,Toposort):-fail.
