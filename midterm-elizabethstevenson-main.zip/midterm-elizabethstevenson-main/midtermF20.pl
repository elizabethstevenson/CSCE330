% Instructions: Please 1) fill out the following Prolog file
% IMPORTANT: make sure you don't have any errors, I may deduct points 
%     for syntax errors, etc. 

% Also IMPORTANT: Do not forget the online quiz (20%).

% (5%) Section 0. Rules and reminders
% What are your initials? (just fill in). This will be unified with the rest
% of the questions from this section
initials(efs).

%initial here if you will follow the Honor Code (change i_agree to initials)
%You are explicitly stating that this work is
% i) your work alone
% ii) you have not consulted with your classmates or anyone else
% iii) any online resources you consult do not trivialize any problem
honor_code(efs).


%you are aware of the online portion of the midterm (20%) on Blackboard
online_portion(efs).


% This take home programming assignment is submitted to GitHub
% IF you have any technical issues, then agree to email me this file
% and submit to Blackboard instead
technical_issues(efs).


% Initial if you understand that you must write GENERAL queries
% I will give you tests, but will use a different set to test your code
%  -- attempts to break/"hack" the test will be penalized heavily 
%  -- an example is just writing facts that answer the tests explicitly
%     versus solving the actual problem
write_general_rules(efs).


%Initial if you will check your final submission on GitHub, by going 
%   directly to Github and looking at your last few changes
%   or cloning to a different directory and checking there.
%   IF you have any issues, you have read that you can submit to 
%   Blackboard (but GitHub is preferred)
submission_and_issues(efs).




% (15%) Section 1. Given a Knowledge Base with the structure in
% midtermTest.pl file
%  write queries to answer the following queries.
%  IMPORTANT: your queries should be sufficiently general 
%     that they work for queries outside the Test file
%     make sure they work for UNSET variables. 

% (5%) Q1.0 calculates the test average -- weighting the midterm an
%  averages should be rounded DOWN (use integral division)
test_avg(ID,Average):- tests(ID,M,F),
    Average is (M+F) // 2.

%(10%) Q1.1 calculates the quiz average. 
% the lowest quiz should be dropped
% i.e. if the quiz grades are 60,70,80,90,100, the average will
% be 85 (including the drop)
% helper functions are allowed

%Please check this one for partial credit
quiz_avg(ID,Average):- quizzes(ID,A,B,C,D,E),
    find_lowest_grade(MIN,A,B,C,D,E),
    Average is (A+B+C+D+E-MIN)//4.

%all these helper functions compares all the grades to find the lowest one
find_lowest_grade(MIN,A,B,C,D,E):-
    A<B, A<C, A<D, A<E,
    MIN is A.

find_lowest_grade(MIN,A,B,C,D,E):-
    B<A, B<C, B<D, B<E,
    MIN is B.

find_lowest_grade(MIN,A,B,C,D,E):-
    C<A, C<B, C<D, C<E,
    MIN is C.

find_lowest_grade(MIN,A,B,C,D,E):-
    D<A, D<B, D<C, D<E,
    MIN is D.

find_lowest_grade(MIN,A,B,C,D,E):-
    E<A, E<B, E<C, E<D,
    MIN is E.


% (20%) Section 2. Problem Representation
% Open the image at the following URL
%   https://cse.sc.edu/~oreillyj/fall20_330_Section_2.png
%   You need to represent the problem in an appropriate way to find
%   the "block_distance" between corners
%   the corners come from the following corner domain
%   the "block_distance" is the MINIMUM number of "block sides" (edges)
%   one would have to traverse to get from one corner to the other
%   Easy ones
%   block_distance(c0,c0, 0). is true
%   block_distance(c0,c1, 1). is true
%   block_distance(c0,c5, 1). is true
%   block_distance(c0,c7, 3). is true
%   block_distance(c5,c10,5). is true
%   block_distance(c10,c5,5). is true (note the flip)
%   Harder Ones
%   block_distance(c2,c3,4). is true
%   block_distance(c3,c2,4). is true (disance is symmetric)
%   block_distance(c5,c4,6). is true (possibly easy)
%   
%   Possibly useful note: abs/1 can be used to calculate 
%   absolute value
%   IF you use a graph representation, this has cycles.
%   My solution uses lists to avoid many cases and not BFS/DFS
%
%   To be clear: Enumerating all possibilities is not acceptable


corner(c0). corner(c1). corner(c2).             corner(c3). corner(c4).
corner(c5). corner(c6). corner(c7). corner(c8). corner(c9). corner(c10).

%took a little bit of guess and checking with the y value being -1 for the Q2 All
grid(c5,0,0). grid(c8,3,0).
grid(c0,0,1). grid(c9,4,0).
grid(c6,1,0). grid(c3,4,-1).
grid(c1,1,1). grid(c10,5,0).
grid(c7,2,0). grid(c4,5,-1).
grid(c2,2,1).

%used coordinate plane method from discussion posts
block_distance(CA,CB,Dist):-
    grid(CA, X1, Y1), grid(CB, X2, Y2),
    Dist is (abs(Y2-Y1) + abs(X2-X1)).

%Section 3: Map Coloring
% color a Six-Pointed star Hexagram with at most 3 colors
% You may not have adjacent "points"/triangles with the same color
% on the Hexagram 
% Look at the example image, linked here:
%     https://cse.sc.edu/~oreillyj/Hexagram.png
% E.g. P1 cannot be the same color as P2  (or P6) or the Center region
% use the below 4 colors
% (certainly not the hardest one of these I've written...)

%Do not modify domain, obviously
color(red). color(blue). color(yellow). color(pink).

color_hexagram(P1,P2,P3,P4,P5,P6,Center):- color(P1), color(P2), color(P3), color(P4), color(P5), color(P6), color(Center),
    %conditions to make sure that no neighbor shapes are touching each other
    \+P1=Center, \+P1=P2,
    \+P2=Center, \+P2=P3,
    \+P3=Center, \+P3=P4,
    \+P4=Center, \+P4=P5,
    \+P5=Center, \+P5=P6,
    \+P6=Center, \+P6=P1,
    %the below shapes can be the same colors that's why they are equal
    P1=P5, P5=P3, P3=P1,
    P2=P4, P4=P6, P2=P6.

%Section 4: Lists
% You may, of course, change any list input/output to any other list
% such as Head/tail notation.

% (10%) Q4.0 Give code to yield a list without any even numbers, e.g.
% remove_evens([10,1,2,21,22],[1,21]). is true
% remove_evens([2,4,6,8],[]). is true
% You may assume the first list (input) is always set and the second unset
% You may assume the input numbers are all nonegative integers'
% The order of the odd numbers should be preserved
% remove_evens([10,1,2,21,22],[21,1]). is FALSE

%remove_evens(Input_List,Output_List)
%empty lists
find_even([],[]).
%finds odds and moves them to the ouput lists and recursions back into the input list
find_even([H|T], Output):- H mod 2 =\= 0,
    Output=[H|TT],
    find_even(T,TT).
%finds even number, moves on, and recursions back into the input
find_even([H|T], Output):- H mod 2 =:= 0,
    find_even(T, Output).
remove_evens(Input,Output):- find_even(Input,Output).

% (10%) Q4.1 Give code to take an input list of alternating numbers
%  and letters and output a list such that the letter is 
%  duplicated the number of times, all in one list, e.g.:
%  You may assume the number is 0 or positive
%  You may also assume the first parameter to dupNChar is set
%     to the above described input list
%  dupNCharList([1,a,2,b,3,c], [a,b,b,c,c,c]). is true
%  dupNCharList([1,a,0,b,2,a], [a,a,a]). is true
%  helper functions are, of course, always allowed

%dupNCharList(InputList,Output)
%empty lists
dupNCharList(In,Out).
%checks for number then duplicates appropriate letter then recursion
dupNCharList([[X|Z]|Y], [[A,X]|B]):- length([X|Z],A),
    dupNCharList(Y,B).

