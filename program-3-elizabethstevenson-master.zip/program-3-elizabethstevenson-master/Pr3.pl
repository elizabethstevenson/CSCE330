%yours
%Q1
mother(M,C):- parent(M,C), female(M).

grand_parent(GP,GC):- parent(GP,P), parent(P,GC).

great_grand_mother(GGM,GGC):- parent(GGM, GP), parent(GP, P), parent(P, GGC), female(GGM).

%Q2
sibling(A,B):- parent(P,A), parent(P,B), \+ A=B.
brother(B,Sib):- sibling(B, Sib), male(B).
sister(S,Sib):- sibling(S,Sib), female(S).

%Q3 --
%You have to know both parents for both siblings for half_sibling
half_sibling(S1,S2):- parent(P1, S1), parent(P1, S2), parent(P2, S1), parent(P3, S2), \+P1=P2, \+P1=P3, \+P2=P3.

full_sibling(S1,S2):- parent(P1, S1), parent(P2, S1), parent(P1, S2), parent(P2, S2), sibling(S1, S2), \+S1=S2, \+P1=P2.

%Q4
first_cousin(C1,C2):- parent(P1, C1), parent(P2, C2), sibling(P1, P2).

second_cousin(C1,C2):- parent(P1, C1), parent(P2, C2), first_cousin(P1, P2), \+ P1=P2, \+C1=C2.

%Q5
half_first_cousin(C1,C2):- parent(P1, C1), parent(P2, C2), half_sibling(P1, P2), \+P1=P2, \+C1=C2.

double_first_cousin(C1,C2):- child(C1,P1), child(C1,P2), child(C2,P3), child(C2,P4), sibling(P1,P3), sibling(P2,P4), \+P1=P2, \+C1=C2, \+P2=P3, \+P1=P3. .

%Q6
first_cousin_twice_removed(C1,C2):- (grand_parent(GP, C2), first_cousin(GP, C1)) ; (grand_parent(GP,C1), first_cousin(GP,C2)).

%Q7
descendant(D,A):- child(D,A).
descendant(D,A):- child(D,X), descendant(X,A).

ancestor(A,D):- parent(A,D).
ancestor(A,D):- parent(A,X), ancestor(X,D).

%Q8
%this version of "cousin" does not handle "____ removed",
%read description carefully
cousin(X,Y):- first_cousin(X,Y).
cousin(X, Y):- parent(P1, X), parent(P2, Y), cousin(P1, P2), \+X=Y, \+P1=P2.


%Q9
%do not return anything for closest_common_ancestor(X,X,A).
helper_function(R1,R2,A):- child(X, A), ancestor(X, R1), ancestor(X, R2).
closest_common_ancestor(R1,R2,A):- ancestor(A, R1), ancestor(A, R2), \+helper_function(R1,R2,A), \+R1=R2.

% Q10 -- not scored, but will do
%   write_descendant_chain(jim,anna) and
%   write_descendant_chain(louise,gina) and
%   write_descendant_chain(emma,lily) <-this one shold print nothing
%   (make sure this does not fail (read the instructions carefully)).

write_child(X,Y):-
	write(X), write(' is a child of '), write(Y), nl.

write_descendant_chain(X,Y):- parent(P,X), write_child(X,P), write_descendant_chain(P,Y), \+X=Y, \+P=X, \+P=Y.



