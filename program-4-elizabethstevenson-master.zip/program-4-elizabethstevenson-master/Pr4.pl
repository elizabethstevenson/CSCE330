
%For all of these, especially the first two, see the examples in the book
%Ignore the Singleton variable warning, that goes away when you 
% define the rules. 

%europe map coloring problem -- use these colors as the domain
%touching fr&ge, ge&au, be&fr, be&ge, fr&sw, ge&sw
%same color be&sw, it&ge, fr&au&ho
color(red, yellow, orange).
europe_color(Fr,Sw,It,Be,Ho,Ge,Au):- color(Fr), color(Sw), color(It), color(Be), color(Ho), color(Ge), color(Au),
\+Fr=Sw, \+Fr=It, \+Fr=Be, \+Fr=Ge,\+Sw=It, \+Sw=Ge, \+Sw=Au, \+Be=Ho, \+Be=Ge, \+Ho=Ge, \+Au=It, \+Au=Ge.


%CROSS + ROADS = DANGER
cryptarithmetic(C,R,O,S,A,D,N,G,E):-
    dig(S), dig(S),
    R is (S+S) mod 10, C1 is (S+S) // 10,
    dig(S), dig(D),
    E is (S+D+C1) mod 10, C10 is (S+D+C1) // 10,
    dig(O), dig(A),
    G is (O+A+C10) mod 10, C100 is (O+A+C10) // 10,
    dig(R), dig(O),
    N is (R+O+C100) mod 10, C1000 is (R+O+C100) // 10,
    dig(C), C > 0, dig(R), R > 0,
    A is (C+R+C1000) mod 10, D is (C+R+C1000) // 10,
    uniq_digits(C,R,O,S,A,D,N,G,E).
    
uniq_digits(C,R,O,S,A,D,N,G,E):-
    dig(C), dig(R), dig(O), dig(S), dig(A), dig(D), dig(N), dig(G), dig(E),
    \+ C=R, \+ C=O, \+ C=S, \+ C=A, \+ C=D, \+ C=N, \+ C=G, \+ C=E,
            \+ R=O, \+ R=S, \+ R=A, \+ R=D, \+ R=N, \+ R=G, \+ R=E,
                    \+ O=S, \+ O=A, \+ O=D, \+ O=N, \+ O=G, \+ O=E,
                            \+ S=A, \+ S=D, \+ S=N, \+ S=G, \+ S=E,
                                    \+ A=D, \+ A=N, \+ A=G, \+ A=E,
                                            \+ D=N, \+ D=G, \+ D=E,
                                                    \+ N=G, \+ N=E,
                                                            \+ G=E.



%Persons are just their names, lower case
who_ordered_pizza(PizzaPerson):-
     uniq_person(Danny,David,Doreen,Donna),
     uniq_person(Steak,Chicken,Lasagna,Pizza),
     uniq_person(Coke,Milk,Coffee,Water),
     across(Doreen,Donna),
     across(Danny,David),
     beside(Doreen,Steak),
     across(Lasagna,Milk),
     Chicken = Coke,
     \+ David = Coffee,
     Donna = Water,
     \+ Danny \= Steak,
     /*
     pmatch(pizza, danny, 'danny'),
     pmatch(pizza, david, 'david'),
     pmatch(pizza, doreen, 'doreen'),
     pmatch(pizza, donna, 'donna'),
     */
     whichPerson(Danny,David,Doreen,Donna,Pizza,PizzaPerson).


/*
pmatch(x,x,Name):- write(Name), write('is the pizza person').
pmatch(x,y,Name):- \+ x=y.
*/

whichPerson(Danny,David,Doreen,Donna,Pizza,PizzaPerson):- (Danny = Pizza, PizzaPerson = 'danny').
whichPerson(Danny,David,Doreen,Donna,Pizza,PizzaPerson):- (David = Pizza, PizzaPerson = 'david').
whichPerson(Danny,David,Doreen,Donna,Pizza,PizzaPerson):- (Doreen = Pizza, PizzaPerson = 'doreen').
whichPerson(Danny,David,Doreen,Donna,Pizza,PizzaPerson):- (Donna = Pizza, PizzaPerson = 'donna').

uniq_person(A,B,C,D):- person(A), person(B), person(C), person(D),
     \+ A=B, \+ A=C, \+ A=D,
             \+ B=C, \+ B=D,
                     \+ C=D.

person(danny). person(david). person(doreen). person(donna).

%table
%      4
%   3 | | 1
%      2

acrossWithNumbers(1,3). acrossWithNumbers(2,4). acrossWithNumbers(3,1). acrossWithNumbers(4,2).
across(x,y):- acrossWithNumbers(x,y), \+ x=y.
across(x,y):- acrossWithNumbers(y,x), \+ x=y.


left(3,4). left(3,2). left(2,1). left(4,1).
beside(x,y):- left(x,y), \+ x=y.
beside(x,y):- left(y,x), \+ x=y.